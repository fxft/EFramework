//
//  EFTRLib.h
//  EFTRLib
//
//  Created by mac on 16/3/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for EFTRLib.
FOUNDATION_EXPORT double EFTRLibVersionNumber;

//! Project version string for EFTRLib.
FOUNDATION_EXPORT const unsigned char EFTRLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EFTRLib/PublicHeader.h>


