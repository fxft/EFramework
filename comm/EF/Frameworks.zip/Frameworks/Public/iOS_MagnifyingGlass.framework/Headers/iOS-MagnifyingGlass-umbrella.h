#import <UIKit/UIKit.h>

#import "ACLoupe.h"
#import "ACMagnifyingGlass.h"
#import "ACMagnifyingView.h"

FOUNDATION_EXPORT double iOS_MagnifyingGlassVersionNumber;
FOUNDATION_EXPORT const unsigned char iOS_MagnifyingGlassVersionString[];

