#import <UIKit/UIKit.h>

#import "OpenUDID.h"

FOUNDATION_EXPORT double OpenUDIDVersionNumber;
FOUNDATION_EXPORT const unsigned char OpenUDIDVersionString[];

