//
//  Bean.h
//  EFExtend
//
//  Created by mac on 15/3/27.
//  Copyright (c) 2015年 Eric. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  数据结构
 */
@interface Bean : NSObject
+ (instancetype)spwan;

@end
