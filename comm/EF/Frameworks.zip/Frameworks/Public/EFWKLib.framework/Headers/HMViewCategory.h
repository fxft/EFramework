//
//  HMViewCategory.h
//  CarAssistant
//
//  Created by Eric on 14-3-11.
//  Copyright (c) 2014年 Eric. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "HMUIContainer.h"

#import "HMCategoryComm.h"

//快速自定义画图工具,可以在HMUIView中进行绘制,控件HMUIPopoverView边框即用该套工具绘制
#import "UIView+HMViewStyle.h"
#import "HMViewShape.h"
#import "HMViewStyle.h"
#import "HMUIStyleSheet.h"


@interface HMViewCategory : NSObject

@end
