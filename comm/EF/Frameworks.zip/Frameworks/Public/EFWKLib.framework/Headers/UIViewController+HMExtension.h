//
//  UIViewController+HMExtension.h
//  CarAssistant
//
//  Created by Eric on 14-3-14.
//  Copyright (c) 2014年 Eric. All rights reserved.
//

#import <UIKit/UIKit.h>
@class UIButten;

@interface UIViewController (HMExtension)

@end
