//
//  HMUITableViewCell.h
//  JNLuckyStar
//
//  Created by Eric on 14-10-22.
//  Copyright (c) 2014年 Eric. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  对HMUIStyle的支持，好像没什么用
 */
@interface HMUITableViewCell : UITableViewCell

@end


@interface UISearchBar (Extend)
- (void)clearBackBar;

@end