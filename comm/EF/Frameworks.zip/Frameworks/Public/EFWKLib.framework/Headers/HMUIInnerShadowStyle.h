//
//  HMUIInnerShadowStyle.h
//  CarAssistant
//
//  Created by Eric on 14-3-12.
//  Copyright (c) 2014年 Eric. All rights reserved.
//

#import "HMUIShadowStyle.h"

@interface HMUIInnerShadowStyle : HMUIShadowStyle

@end
