//
//  HMUIRectangleShape.h
//  CarAssistant
//
//  Created by Eric on 14-3-12.
//  Copyright (c) 2014年 Eric. All rights reserved.
//

#import "HMUIShape.h"

@interface HMUIRectangleShape : HMUIShape


@end
