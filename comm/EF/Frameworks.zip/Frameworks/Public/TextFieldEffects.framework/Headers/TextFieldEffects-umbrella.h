#import <UIKit/UIKit.h>


FOUNDATION_EXPORT double TextFieldEffectsVersionNumber;
FOUNDATION_EXPORT const unsigned char TextFieldEffectsVersionString[];

