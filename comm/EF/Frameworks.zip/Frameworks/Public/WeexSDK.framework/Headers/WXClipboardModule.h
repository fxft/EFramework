//
//  WXClipboardModule.h
//  WeexSDK
//
//  Created by Jun Shi on 7/21/16.
//  Copyright © 2016 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WXModuleProtocol.h"

@interface WXClipboardModule : NSObject <WXModuleProtocol>

@end
