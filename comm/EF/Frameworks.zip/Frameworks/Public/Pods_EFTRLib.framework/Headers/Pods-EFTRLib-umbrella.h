#import <UIKit/UIKit.h>


FOUNDATION_EXPORT double Pods_EFTRLibVersionNumber;
FOUNDATION_EXPORT const unsigned char Pods_EFTRLibVersionString[];

