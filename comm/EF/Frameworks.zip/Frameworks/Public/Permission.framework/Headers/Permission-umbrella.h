#import <UIKit/UIKit.h>


FOUNDATION_EXPORT double PermissionVersionNumber;
FOUNDATION_EXPORT const unsigned char PermissionVersionString[];

