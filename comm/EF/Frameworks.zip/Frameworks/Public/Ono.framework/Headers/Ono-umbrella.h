#import <UIKit/UIKit.h>

#import "Ono.h"
#import "ONOXMLDocument.h"

FOUNDATION_EXPORT double OnoVersionNumber;
FOUNDATION_EXPORT const unsigned char OnoVersionString[];

