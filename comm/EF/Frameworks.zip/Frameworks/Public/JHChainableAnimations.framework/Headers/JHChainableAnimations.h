//
//  JHAnimationKit.h
//  JHAnimationKitExample
//
//  Created by Jeff Hurray on 4/29/15.
//  Copyright (c) 2015 jhurray. All rights reserved.
//

#ifndef JHAnimationKitExample_JHChainableAnimations_h
#define JHAnimationKitExample_JHChainableAnimations_h

#import "UIView+JHChainableAnimations.h"

#endif
