#import <UIKit/UIKit.h>

#import "TAAbstractDotView.h"
#import "TAAnimatedDotView.h"
#import "TADotView.h"
#import "TAPageControl.h"
#import "SDCollectionViewCell.h"
#import "SDCycleScrollView.h"
#import "UIView+SDExtension.h"

FOUNDATION_EXPORT double SDCycleScrollViewVersionNumber;
FOUNDATION_EXPORT const unsigned char SDCycleScrollViewVersionString[];

